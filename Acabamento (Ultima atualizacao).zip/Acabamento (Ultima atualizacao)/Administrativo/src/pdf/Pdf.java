/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pdf;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import dao.VendaDao;
import java.awt.Desktop;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import static main.Pagamento.jLabel7;
import model.Venda;

/**
 *
 * @author elves
 */
public class Pdf {
    
    
    public void gerarPdf(){  
       
         
          Document document = new Document();
          try {
             
              PdfWriter.getInstance(document, new FileOutputStream("documento.pdf"));
              document.open();
              document.setPageSize(PageSize.A4);
             
              
              Paragraph p = new Paragraph("venda");
              p.setAlignment(1);
              document.add(p);
              p= new Paragraph();
              document.add(p);
              
               try {
            VendaDao vd = new VendaDao();
            Venda  v1 = new Venda();
                  
          String numero = jLabel7.getText();
          v1 = vd.consultarvendaPDF(numero);
                  
            
            PdfPTable table = new PdfPTable(6);

PdfPCell leitor = new PdfPCell(new Paragraph("" ));
PdfPCell leitor2 = new PdfPCell(new Paragraph("data"));
PdfPCell leitor3 = new PdfPCell(new Paragraph("produto"));
PdfPCell leitor4 = new PdfPCell(new Paragraph("valor"));
PdfPCell leitor5 = new PdfPCell(new Paragraph("quantidade"));
PdfPCell leitor6 = new PdfPCell(new Paragraph("celular"));
PdfPCell leitor7 = new PdfPCell(new Paragraph("cliente"));
 table.setTotalWidth(550);
 table.setLockedWidth(true);

 
 
 


leitor.setColspan(6);
table.addCell(leitor2); 
table.addCell(leitor3); 
table.addCell(leitor4); 
table.addCell(leitor5); 
table.addCell(leitor6); 
table.addCell(leitor7); 
table.addCell(leitor); 
                   
     
                       
         leitor2 = new PdfPCell(new Paragraph(v1.getDataVenda()));
         leitor3 = new PdfPCell(new Paragraph(v1.getNomeVenda()));
         leitor4 = new PdfPCell(new Paragraph(v1.getValorVenda()));
         leitor5 = new PdfPCell(new Paragraph(v1.getQuantVenda()+""));
         leitor6 = new PdfPCell(new Paragraph(v1.getCelularcliente()));
         leitor7 = new PdfPCell(new Paragraph(v1.getNomecliente()));
        
         
table.addCell(leitor2); /*aqui estou colocando cada leitor com o objeto trazido do banco dentro da tabela */
table.addCell(leitor3); 
table.addCell(leitor4); 
table.addCell(leitor5); 
table.addCell(leitor6); 
table.addCell(leitor7); 
table.addCell(leitor); 

         
                       
      document.add(table);                 
            
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Pdf.class.getName()).log(Level.SEVERE, null, ex);
        }
           
}
          catch(DocumentException | IOException de) {
              System.err.println(de.getMessage());
              JOptionPane.showMessageDialog(null, de.getMessage());
          }
          document.close();
        try {
            Desktop.getDesktop().open(new File("documento.pdf"));
        } catch (IOException ex) {
            Logger.getLogger(Pdf.class.getName()).log(Level.SEVERE, null, ex);
            
        }
      }
      
       
           
    }
        
    
    


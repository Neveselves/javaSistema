
package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import model.Venda;

/**
 *
 * @author elves
 */
public class VendaDao {
    private final String SHEMA = "cadastro";
    private final String CAMINHO = "jdbc:mysql://localhost/"+SHEMA;
    private final String USUARIO_BD= "root";
    private final String SENHA_BD = "";
    
    //QUERY's =================
     private final String CADASTRAR_VENDA = "INSERT INTO venda (data, nome, valor, vendaquantidade,celularcli, nomecli) VALUES (?, ?, ?, ?, ?, ?)";
   
       private final String CONSULTAR_VENDA = "SELECT * FROM venda WHERE data = ?";
       private final String CONSULTAR_VENDAPDF = "SELECT * FROM venda WHERE celularcli = ?";
     

    
    //conexão com o BD =======
        private static Connection connection = null;
        private static PreparedStatement stmt = null;
        private static ResultSet resultSet = null;
    //========================
    
    //Construtor ALt+INSERT

    public VendaDao() throws ClassNotFoundException {
        //registrar o driver JDBC
        Class.forName ("com.mysql.jdbc.Driver");
    }
     
     public void cadastrar_venda(Venda v1) throws SQLException, ClassNotFoundException{
        //conexão com o banco de dados======
        connection = DriverManager.getConnection(CAMINHO, USUARIO_BD, SENHA_BD);
        System.out.println("Conectou ao banco!!!!");
        //==============================
        
        //Preparar a Query===========
        String query = CADASTRAR_VENDA;
        stmt = connection.prepareStatement(query);
        stmt.setString(1,v1.getDataVenda());
        stmt.setString(2,v1.getNomeVenda());
        stmt.setString(3,v1.getValorVenda());
        stmt.setInt(4,v1.getQuantVenda());
        stmt.setString(5,v1.getCelularcliente());
        stmt.setString(6,v1.getNomecliente());
       
        stmt.execute();
        
        System.out.println("Cadastrado com sucesso!!!");
        
       
        
        //fechar conexao
        stmt.close();
        connection.close();
        System.out.println("Fechou Conexão");       
    }
    
     public ArrayList<Venda> consultarVenda( String data) throws SQLException
     {          
        //conexão com o banco de dados======
        connection = DriverManager.getConnection(CAMINHO, USUARIO_BD, SENHA_BD);
        System.out.println("Conectou ao banco!!!!");
        //==============================        
        //Preparar a Query===========
        String query = CONSULTAR_VENDA ;
        stmt = connection.prepareStatement(query);
        stmt.setString(1, data);      
        
        //execulta a query
        resultSet = stmt.executeQuery();
         ArrayList<Venda> lista1 = new ArrayList<>();
        
      
       
        while (resultSet.next()){
             Venda v1 = new Venda();
             v1.setDataVenda(resultSet.getString(2));
             v1.setNomeVenda(resultSet.getString(3));
             v1.setValorVenda(resultSet.getString(4));
             v1.setQuantVenda(resultSet.getInt(5));
             v1.setCelularcliente(resultSet.getString(6));
             v1.setNomecliente(resultSet.getString(7));
             
            
             lista1.add(v1);
        }
                   
        //fechar conexao
        stmt.close();
        resultSet.close();
        connection.close();
        System.out.println("Fechou Conexão");       
       
        return lista1;
        
     }
     public Venda consultarvendaPDF(String contato) throws SQLException{
        
        //conexão com o banco de dados======
        connection = DriverManager.getConnection(CAMINHO, USUARIO_BD, SENHA_BD);
        System.out.println("Conectou ao banco!!!!");
        //==============================
        
        //Preparar a Query===========
        String query = CONSULTAR_VENDAPDF ;
        stmt = connection.prepareStatement(query);
        stmt.setString(1, contato);      
        
        //execulta a query
        resultSet = stmt.executeQuery();
        
       Venda v1 = new Venda();
        
        while(resultSet.next()){
             
             v1.setDataVenda(resultSet.getString(2));
             v1.setNomeVenda(resultSet.getString(3));
             v1.setValorVenda(resultSet.getString(4));
             v1.setQuantVenda(resultSet.getInt(5));
             v1.setCelularcliente(resultSet.getString(6));
             v1.setNomecliente(resultSet.getString(7));
                       
             
        }
                   
        //fechar conexao
        stmt.close();
        resultSet.close();
        connection.close();
        System.out.println("Fechou Conexão");       
        return v1;
       
     }
     
}
    
    
    



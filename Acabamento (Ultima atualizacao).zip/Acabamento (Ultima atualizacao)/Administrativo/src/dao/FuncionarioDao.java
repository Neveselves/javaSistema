/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import model.Funcionario;

/**
 *
 * @author elves
 */
public class FuncionarioDao {
    
       //DADOS DO BANCO DE DADOS
    private final String SHEMA = "cadastro";
    private final String CAMINHO = "jdbc:mysql://localhost/"+SHEMA;
    private final String USUARIO_BD= "root";
    private final String SENHA_BD = "";
    
    
    private final String CADASTRAR_FUNCIONARIO  = "INSERT INTO funcionario (matricula,nomefunc,cargo,cargahoraria) VALUES (?, ?, ?, ?)";
    private final String ATUALIZAR_CARGO_PELO_MATRIC = "UPDATE funcionario SET cargo = ? WHERE matricula = ?";
    private final String DELETAR_FUNCIONARIO_PELO_MATRIC = "DELETE FROM funcionario WHERE matricula = ?";
    
    private static Connection connection = null;
    private static PreparedStatement stmt = null;
    private static ResultSet resultSet = null;
        
         public FuncionarioDao() throws ClassNotFoundException {
        //registrar o driver JDBC
        Class.forName ("com.mysql.jdbc.Driver");
    }
    
    
    
      public void Cadastrar_Funcionario(Funcionario f1) throws SQLException{
        //conexão com o banco de dados======
        connection = DriverManager.getConnection(CAMINHO, USUARIO_BD, SENHA_BD);
        System.out.println("Conectou ao banco!!!!");
        //==============================
        
        //Preparar a Query===========
        String query = CADASTRAR_FUNCIONARIO;
        stmt = connection.prepareStatement(query);
        stmt.setInt(1,f1.getMatricula());
        stmt.setString(2,f1.getNomefunc());
        stmt.setString(3,f1.getCargo());
        stmt.setInt(4,f1.getCargahora());
        
        
        
        //execulta a query
        stmt.execute();
        System.out.println("Cadastrado com sucesso!!!");
        
        //fechar conexao
        stmt.close();
        connection.close();
        System.out.println("Fechou Conexão");       
    }
       public void atulaizarcargoPelomatric (String novocargo, int matricu) throws SQLException{
        
        //conexão com o banco de dados======
        connection = DriverManager.getConnection(CAMINHO, USUARIO_BD, SENHA_BD);
        System.out.println("Conectou ao banco!!!!");
        //==============================   
        
        //Preparar a Query===========
        String query = ATUALIZAR_CARGO_PELO_MATRIC;
        stmt = connection.prepareStatement(query);
        stmt.setString(1, novocargo);
        stmt.setInt(2, matricu);      
        
        //execulta a query
        stmt.executeUpdate();
        
        //fechar conexao
        stmt.close();
        connection.close();
        System.out.println("Fechou Conexão");
        
}
        public void deletarfuncionarioPelomatricu(int matricu) throws SQLException{
        
        //conexão com o banco de dados======
        connection = DriverManager.getConnection(CAMINHO, USUARIO_BD, SENHA_BD);
        System.out.println("Conectou ao banco!!!!");
        //==============================   
        
        //Preparar a Query===========
        String query = DELETAR_FUNCIONARIO_PELO_MATRIC;
        stmt = connection.prepareStatement(query);
        stmt.setInt(1, matricu);     
        
        //execulta a query
        stmt.execute();
        
        //fechar conexao
        stmt.close();
        connection.close();
        System.out.println("Fechou Conexão");
        
    }
    
}
